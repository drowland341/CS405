// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom Exception Occurred!";
    }
};

// Function that throws a standard C++ exception
bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // TODO: Throw any standard exception
    throw std::runtime_error("Runtime error in do_even_more_custom_application_logic!");

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Function to divide two numbers, throwing exception for divide by zero
float divide(float num, float den)
{
    if (den == 0) {
        // TODO: Throw an exception to deal with divide by zero errors using a standard C++ defined exception
        throw std::invalid_argument("Division by zero error!");
    }

    return (num / den);
}

// Function that calls divide() and handles only division-related exceptions
void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cerr << "Exception caught in do_division: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        std::cerr << "CustomException caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "std::exception caught in main: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Unknown exception caught in main!" << std::endl;
    }

    std::cout << "Program execution completed!" << std::endl;
    return 0;
}
