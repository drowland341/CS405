// QuestionableCode.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// This code is very questionable. Do not take anything you find in here seriously. 
//

#include <cassert>
#include <iostream>
#include <numeric>
#include <set>
#include <vector>

// TODO: You are going to compare the warnings & errors between Visual Studio and CppCheck.
//  Make sure you are using CppCheck 2.1 or greater
//
//  1. Create a Visual Studio Console project with this file as the only file
//  2. Compile it and check the warning and errors
//  3. Create a CppCheck project to analyze a Visual Studio project with this file.
//  4. In CppCheck Edit / Preferences / General Tab: Set Display error id in column "Id", Enable inline suppressions, and Check for inconclusive errors also
//  5. In CppCheck View, Select Check All to ensure all types of checks are enabled
//  6. In CppCheck Analyze, set the C++ Standard to C++17, and Enforce C++
//  7. Make sure to run the analysis
//  8. Save the results to a file (XML format)
//  9. Take a screen shot of the Visual Studio Error list (all errors, warnings, and messages)
//  10. Identify all messages from CppCheck NOT identified in Visual Studio.
//      For each message not in both:
//        Identify the risk as: RISK or NOT RISK
//        Identify which system (Visual Studio or CppCheck) found the issue
//        Provide a couple of sentences describing the issue found

class C
{
    std::set<int> typedefs;

public:
    bool is_type(int type) const
    {
        if (typedefs.find(type) != typedefs.end())
            return typedefs.find(type) != typedefs.end(); // FIXED: endless recursion
        return false;
    }
};

class A
{
    int x;

public:
    A(int val) : x(val) {}
    A(const A& other) = delete; // Fix: Deleted copy constructor to prevent unintended copying
};

class MySpecialType
{
public:
    int MyVal = 1;

    void DontThrow() noexcept
    {
        std::cerr << "Ha! I threw anyway!" << std::endl;
    }
};

void foo(int** a)
{
    static int b = 1; // Fix: Changed local `b` to static to avoid returning pointer to stack variable
    *a = &b;
}

void work_with_arrays(int count)
{
    int buf[10];
    if (count < 10) // Fix: Prevents out-of-bounds error
        buf[count] = 0;
    else
        std::cerr << "Index out of bounds!" << std::endl;
}

void do_something_useless()
{
    int sum = 0;
    for (int i = 0; i < 1000; ++i)
    {
        sum += i;
    }

    std::cout << "I summed up " << sum << " as the answer." << std::endl;
}

void vector_test()
{
    std::vector<int> items;
    items.push_back(1);
    items.push_back(2);
    items.push_back(3);

    std::vector<int>::iterator iter = items.begin();
    while (iter != items.end()) {
        if (*iter == 2) {
            iter = items.erase(iter);  // Erase and update iterator
        }
        else {
            ++iter; // Only increment if not erasing
        }
}

bool my_function()
{
    int a = 1 + 2;  // Declare a local variable instead of modifying the global 'a'
    return a == 3;
}


struct Token
{
    Token* next() { return nullptr; }
};

int foo(Token* tok)
{
    while (tok) // FIXED: Removed unecessary semicolon
    {
        tok = tok->next();
    }

    return 0;
}

int main()
{
    std::vector<int> counts{ 1, 2, 3, 5 };
    int x = 0;
    int y = 0;
    int z = 0;

    std::cout << "Welcome to the Questionable Code Test!" << std::endl;

    // do_something_useless(); //Unsure if needs to be used or not but it says its useless...so I guess it stays commented out

    work_with_arrays(10);

    assert(z == 2); // FIXED: Changed = to ==

    assert(my_function() == true); // FIXED: changed the assert my_function to equal true

    try
    {
        int x = 5;
        int y = 5;
        int z = 5;
        std::cout << "x + y + z = " << (x + y + z) << std::endl;
    }
    catch (...)
    {
        std::cerr << "An exception occurred!" << std::endl;
    }

    int* c;
    foo(&c);

    vector_test();

    MySpecialType myobject;
    std::cout << "myobject.MyVal = " << myobject.MyVal << std::endl; 
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu